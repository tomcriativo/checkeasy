$(document).ready(function(){
  $('#placa-veiculo').mask('ABC-0000');
  $('#phone-number').mask('0000-0000');
});